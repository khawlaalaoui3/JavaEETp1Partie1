import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CalculDeMonImc")
public class CalculDeMonImc extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String poidsStr = request.getParameter("poids");
        String tailleStr = request.getParameter("taille");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (poidsStr == null || tailleStr == null || poidsStr.isEmpty() || tailleStr.isEmpty()) {
            out.println("<h2>Veuillez entrer un poids et une taille valides.</h2>");
            return;
        }

        try {
            double poids = Double.parseDouble(poidsStr.trim());
            double taille = Double.parseDouble(tailleStr.trim());

            IMC monImc = new IMC(taille, poids);
            double imc = monImc.calcul();

            out.println("<h2>Votre IMC est : " + String.format("%.2f", imc) + "</h2>");
        } catch (NumberFormatException e) {
            out.println("<h2>Erreur : Veuillez entrer des valeurs numériques valides.</h2>");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        doGet(request, response);
    }
}
